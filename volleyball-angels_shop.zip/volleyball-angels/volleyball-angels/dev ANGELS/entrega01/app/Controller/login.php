<?php 
    header("Content-type: application/json;charset:utf-8");
    echo json_encode($_POST); 
?>