anime({
    targets: '.conteudo',
    translateX: ['-100%', '0%'],
    duration: 6000,
    easing: 'linear',
    loop: true
});

